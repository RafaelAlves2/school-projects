﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Exercício_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Apenas valores pares
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = Convert.ToInt32(textBox12.Text);

                if (numero % 2 != 0)
                    throw new Exception("Só são permitidos números pares.");

                MessageBox.Show("Número válido!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce apenas números.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Valor dentro do intervalo
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = Convert.ToInt32(textBox6.Text);

                if (numero < 10 || numero > 20)
                    throw new ArgumentOutOfRangeException("", "O valor deve estar entre 10 e 20.");

                MessageBox.Show("Valor dentro do intervalo.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce apenas números.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Mês
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int mes = Convert.ToInt32(textBox9.Text);

                switch (mes)
                {
                    case 1: MessageBox.Show("Janeiro"); break;
                    case 2: MessageBox.Show("Fevereiro"); break;
                    case 3: MessageBox.Show("Março"); break;
                    case 4: MessageBox.Show("Abril"); break;
                    case 5: MessageBox.Show("Maio"); break;
                    case 6: MessageBox.Show("Junho"); break;
                    case 7: MessageBox.Show("Julho"); break;
                    case 8: MessageBox.Show("Agosto"); break;
                    case 9: MessageBox.Show("Setembro"); break;
                    case 10: MessageBox.Show("Outubro"); break;
                    case 11: MessageBox.Show("Novembro"); break;
                    case 12: MessageBox.Show("Dezembro"); break;
                    default: throw new ArgumentOutOfRangeException("", "Mês inválido.");
                }
            }
            catch (ArgumentOutOfRangeException erro)
            {
                MessageBox.Show("Atenção: " + erro.Message);
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message);
            }
        }

        // mês
        private string nomeMes(int num_mes)
        {
            switch (num_mes)
            {
                case 1: return "Janeiro";
                case 2: return "Fevereiro";
                case 3: return "Março";
                case 4: return "Abril";
                case 5: return "Maio";
                case 6: return "Junho";
                case 7: return "Julho";
                case 8: return "Agosto";
                case 9: return "Setembro";
                case 10: return "Outubro";
                case 11: return "Novembro";
                case 12: return "Dezembro";
                default: throw new ArgumentOutOfRangeException("", "Mês inválido.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int mes = Convert.ToInt32(textBox11.Text);
                MessageBox.Show("O mês digitado é: " + nomeMes(mes));
            }
            catch (ArgumentOutOfRangeException md)
            {
                MessageBox.Show("Atenção: " + md.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // divisão por zero
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox8.Text);
                int b = Convert.ToInt32(textBox7.Text);

                int resultado = a / b;

                MessageBox.Show("Resultado: " + resultado);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("Não podes dividir por zero.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Adicione apenas números.");
            }
        }

    }
}