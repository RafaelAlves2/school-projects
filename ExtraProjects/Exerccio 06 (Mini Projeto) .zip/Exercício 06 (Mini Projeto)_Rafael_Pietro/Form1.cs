﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercício_06__Mini_Projeto__Rafael_Pietro
{
    public partial class Form1 : Form
    {
        // Listas para permitir múltiplas instâncias
        List<Carro> carros = new List<Carro>();
        List<Moto> motos = new List<Moto>();
        List<Caminhao> caminhoes = new List<Caminhao>();

        public Form1()
        {
            InitializeComponent();
        }

        // ================= CARRO =================
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
                return;
            }

            if (!double.TryParse(textBox3.Text, out double preco) || preco <= 0)
            {
                MessageBox.Show("Preço inválido!");
                return;
            }

            Carro novoCarro = new Carro(textBox1.Text, textBox2.Text, preco, textBox4.Text);
            carros.Add(novoCarro);

            listBox1.Items.Add("CARRO - " + textBox1.Text + " " + textBox2.Text + " - " + preco.ToString("F2") + "€");

            LimparCarro();
            MessageBox.Show("Carro adicionado com sucesso!");
        }

        // ================= CAMINHÃO =================
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox9.Text == "" || textBox10.Text == "" || textBox11.Text == "" || textBox12.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
                return;
            }

            if (!double.TryParse(textBox11.Text, out double preco) || preco <= 0)
            {
                MessageBox.Show("Preço inválido!");
                return;
            }

            Caminhao novoCaminhao = new Caminhao(textBox9.Text, textBox10.Text, preco, textBox12.Text);
            caminhoes.Add(novoCaminhao);

            listBox1.Items.Add("CAMINHÃO - " + textBox9.Text + " " + textBox10.Text + " - " + preco.ToString("F2") + "€");

            LimparCaminhao();
            MessageBox.Show("Caminhão adicionado com sucesso!");
        }

        // ================= MOTO =================
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!");
                return;
            }

            if (!double.TryParse(textBox7.Text, out double preco) || preco <= 0)
            {
                MessageBox.Show("Preço inválido!");
                return;
            }

            Moto novaMoto = new Moto(textBox5.Text, textBox6.Text, preco, textBox8.Text);
            motos.Add(novaMoto);

            listBox1.Items.Add("MOTO - " + textBox5.Text + " " + textBox6.Text + " - " + preco.ToString("F2") + "€");

            LimparMoto();
            MessageBox.Show("Moto adicionada com sucesso!");
        }

        // ================= BLOQUEAR NÚMEROS =================
        private void BloquearNumeros(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
                e.Handled = true;
        }

        // ================= LIMPAR CAMPOS =================
        private void LimparCarro()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void LimparMoto()
        {
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
        }

        private void LimparCaminhao()
        {
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
        }

        // ================= RESTO DOS EVENTOS =================
        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void tabPage2_Click(object sender, EventArgs e) { }
        private void label13_Click(object sender, EventArgs e) { }
        private void Form1_Load(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }
        private void label15_Click(object sender, EventArgs e) { }
        private void label14_Click(object sender, EventArgs e) { }
        private void textBox16_TextChanged(object sender, EventArgs e) { }
        private void textBox15_TextChanged(object sender, EventArgs e) { }
        private void textBox14_TextChanged(object sender, EventArgs e) { }
        private void textBox13_TextChanged(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }
        private void label12_Click(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void textBox12_TextChanged(object sender, EventArgs e) { }
        private void textBox11_TextChanged(object sender, EventArgs e) { }
        private void textBox10_TextChanged(object sender, EventArgs e) { }
        private void textBox9_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
    }
}