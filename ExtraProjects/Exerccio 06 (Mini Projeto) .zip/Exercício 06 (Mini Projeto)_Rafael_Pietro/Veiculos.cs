﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_06__Mini_Projeto__Rafael_Pietro
{
    public class Artigo
    {
        public string Marca;
        public string Modelo;
        public double Preco;
        public string Tipo;

        public Artigo(string marca, string modelo, double preco, string tipo)
        {
            Marca = marca;
            Modelo = modelo;
            Preco = preco;
            Tipo = tipo;
        }
    }

    public class Carro : Artigo
    {
        public Carro(string marca, string modelo, double preco, string tipo)
            : base(marca, modelo, preco, tipo)
        {
        }
    }

    public class Moto : Artigo
    {
        public Moto(string marca, string modelo, double preco, string tipo)
            : base(marca, modelo, preco, tipo)
        {
        }
    }

    public class Caminhao : Artigo
    {
        public Caminhao(string marca, string modelo, double preco, string tipo)
            : base(marca, modelo, preco, tipo)
        {
        }
    }
}
