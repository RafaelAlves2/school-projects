﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_rafael_sergio
{
    abstract class Veiculo
    {
        protected string marca;
        protected string modelo;
        protected int ano;

        public Veiculo(string marca, string modelo, int ano)
        {
            this.marca = marca;
            this.modelo = modelo;
            this.ano = ano;
        }

        public abstract void Acelerar();
        public abstract void Travar();

        public virtual string Tipo()
        {
            return this.GetType().Name;
        }

        public virtual void MostrarEstado()
        {
            Console.WriteLine($"Marca: {marca} | Modelo: {modelo} | Ano: {ano} | Tipo: {Tipo()}");
        }

        public override string ToString()
        {
            return $"Marca: {marca} | Modelo: {modelo} | Ano: {ano} | Tipo: {Tipo()}";
        }

        static void Main(string[] args)
        {
            Automovel a1 = new Automovel("Ford", "Focus", 2010, 5);
            Motociclo m1 = new Motociclo("Yamaha", "XTZ", 2018, false);
            AutomovelEletrico ae1 = new AutomovelEletrico("Tesla", "Model 3", 2022, 5);
            MotocicloEletrico me1 = new MotocicloEletrico("Zero", "SR/F", 2020, false);

            Automovel a2 = new Automovel("Renault", "Clio", 2015, 4);
            MotocicloEletrico me2 = new MotocicloEletrico("Super Soco", "TC Max", 2023, false);

            BicicletaEletrica be1 = new BicicletaEletrica("Xiaomi", "Himo", 2022);

            Console.WriteLine("\n=== Veículos Criados ===");
            Console.WriteLine(a1);
            Console.WriteLine(m1);
            Console.WriteLine(ae1);
            Console.WriteLine(me1);
            Console.WriteLine(a2);
            Console.WriteLine(me2);
            Console.WriteLine(be1);

            Console.WriteLine("\n=== Testes Individuais ===");
            a1.Acelerar(); a1.Travar();
            m1.Acelerar(); m1.Travar();
            a2.Acelerar(); a2.Travar();

            ae1.Acelerar();
            me1.Acelerar();
            me2.Acelerar();
            be1.Acelerar();

            Console.WriteLine($"\nBateria automóvel elétrico: {ae1.NivelBateria()}%");
            Console.WriteLine($"Bateria mota elétrica: {me1.NivelBateria()}%");
            Console.WriteLine($"Bateria mota elétrica: {me2.NivelBateria()}%");
            Console.WriteLine($"Bateria bicicleta elétrica: {be1.NivelBateria()}%");

            List<Veiculo> frota = new List<Veiculo> { a1, m1, ae1, me1, a2, me2, be1 };

            Console.WriteLine("\n=== Teste Polimórfico e MostrarEstado ===");
            foreach (var v in frota)
            {
                v.MostrarEstado();
                v.Acelerar();
                v.Acelerar();
                v.Travar();

                if (v is IVeiculoEletrico ev)
                {
                    Console.WriteLine($"Bateria atual: {ev.NivelBateria()}%");
                }
                Console.WriteLine();
            }

            Console.WriteLine("=== Recuperar Bateria de Todos os Elétricos ===");
            RecuperarBateria(frota);

            Console.WriteLine("Fim dos testes.");
            Console.ReadKey();
        }

        public static void RecuperarBateria(List<Veiculo> frota)
        {
            foreach (var v in frota)
            {
                if (v is IVeiculoEletrico ev)
                {
                    ev.CarregarBateria();
                    Console.WriteLine("Bateria carregada a 100%.");
                }
            }

            foreach (var v in frota)
            {
                if (v is IVeiculoEletrico ev)
                {
                    Console.WriteLine($"{v.Tipo()} bateria recarregada: {ev.NivelBateria()}%");
                }
            }
        }
    }

    class Automovel : Veiculo
    {
        private int numeroPortas;

        public Automovel(string marca, string modelo, int ano, int numeroPortas)
            : base(marca, modelo, ano)
        {
            this.numeroPortas = numeroPortas;
        }

        public override void Acelerar() => Console.WriteLine("O automóvel está a acelerar.");
        public override void Travar() => Console.WriteLine("O automóvel está a travar.");
    }

    class Motociclo : Veiculo
    {
        private bool temSidecar;

        public Motociclo(string marca, string modelo, int ano, bool temSidecar)
            : base(marca, modelo, ano)
        {
            this.temSidecar = temSidecar;
        }

        public override void Acelerar() => Console.WriteLine("A mota está a acelerar.");
        public override void Travar() => Console.WriteLine("A mota está a travar.");
    }

    public interface IVeiculoEletrico
    {
        void CarregarBateria();
        int NivelBateria();
    }

    class AutomovelEletrico : Automovel, IVeiculoEletrico
    {
        private int bateria;

        public AutomovelEletrico(string marca, string modelo, int ano, int numeroPortas)
            : base(marca, modelo, ano, numeroPortas)
        {
            bateria = 100;
        }

        public override void Acelerar()
        {
            if (bateria > 0)
            {
                Console.WriteLine("O automóvel elétrico está a acelerar silenciosamente.");
                bateria -= 15;
                if (bateria < 0) bateria = 0;
            }
            else
            {
                Console.WriteLine("A bateria está a 0%. Não é possível acelerar!");
            }
        }

        public override void Travar() => Console.WriteLine("O automóvel elétrico está a travar (regeneração ativa).");

        public void CarregarBateria() => bateria = 100;
        public int NivelBateria() => bateria;
    }

    class MotocicloEletrico : Motociclo, IVeiculoEletrico
    {
        private int bateria;

        public MotocicloEletrico(string marca, string modelo, int ano, bool temSidecar)
            : base(marca, modelo, ano, temSidecar)
        {
            bateria = 100;
        }

        public override void Acelerar()
        {
            if (bateria > 0)
            {
                Console.WriteLine("A mota elétrica está a acelerar silenciosamente.");
                bateria -= 10;
                if (bateria < 0) bateria = 0;
            }
            else
            {
                Console.WriteLine("A bateria está a 0%. Não é possível acelerar!");
            }
        }

        public override void Travar() => Console.WriteLine("A mota elétrica está a travar.");

        public void CarregarBateria() => bateria = 100;
        public int NivelBateria() => bateria;
    }

    class BicicletaEletrica : Veiculo, IVeiculoEletrico
    {
        private int bateria;

        public BicicletaEletrica(string marca, string modelo, int ano)
            : base(marca, modelo, ano)
        {
            bateria = 100;
        }

        public override void Acelerar()
        {
            if (bateria > 0)
            {
                Console.WriteLine("A bicicleta elétrica está a acelerar.");
                bateria -= 5;
                if (bateria < 0) bateria = 0;
            }
            else
            {
                Console.WriteLine("A bateria está a 0%. Não é possível acelerar!");
            }
        }

        public override void Travar() => Console.WriteLine("A bicicleta elétrica está a travar.");

        public void CarregarBateria() => bateria = 100;
        public int NivelBateria() => bateria;
    }
}   
