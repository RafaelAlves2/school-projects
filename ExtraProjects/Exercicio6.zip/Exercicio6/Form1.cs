﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Exercicio6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Ficheiros de texto (*.txt)|*.txt|Todos os ficheiros (*.*)|*.*";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.Text = File.ReadAllText(openFileDialog.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir o ficheiro: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Ficheiros de texto (*.txt)|*.txt|Todos os ficheiros (*.*)|*.*";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog.FileName, richTextBox1.Text);
                    MessageBox.Show("Ficheiro guardado com sucesso!");
                }
            }
            catch (IOException)
            {
                MessageBox.Show("Erro ao guardar o ficheiro.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Image imagem = Image.FromFile(openFileDialog.FileName);
                    richTextBox1.Paste();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar a imagem: " + ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle estiloAtual = richTextBox1.SelectionFont.Style;
                bool estaNegrito = richTextBox1.SelectionFont.Bold;

                // Alterna o estado do negrito
                if (estaNegrito)
                    estiloAtual &= ~FontStyle.Bold;   
                else
                    estiloAtual |= FontStyle.Bold;    

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, estiloAtual);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle estiloAtual = richTextBox1.SelectionFont.Style;
                bool estaItalico = richTextBox1.SelectionFont.Italic;

                if (estaItalico)
                    estiloAtual &= ~FontStyle.Italic;   
                else
                    estiloAtual |= FontStyle.Italic;    

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, estiloAtual);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle estiloAtual = richTextBox1.SelectionFont.Style;
                bool estaSublinhado = richTextBox1.SelectionFont.Underline;

                if (estaSublinhado)
                    estiloAtual &= ~FontStyle.Underline;  
                else
                    estiloAtual |= FontStyle.Underline;   

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, estiloAtual);
            }
        }
    }
}
