﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2
{
    public class Conta
    {
        public int numero;
        public double saldo;

        public Conta(int num)
        { numero = num; }

        public double ConsultaSaldo()
        { return saldo; }
        public void levantar(int valor)
        { saldo -= valor; }
        public void depositar(int valor)
        { saldo += valor; }
    }
}
