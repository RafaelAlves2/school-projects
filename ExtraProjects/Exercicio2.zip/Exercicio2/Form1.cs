﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Exercicio2
{
    public partial class Form1 : Form
    {
        public Conta ct1;
        public Conta ct2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ct1 = new Conta(1);
            ct2 = new Conta(2);
            ct1.saldo = 100;
            ct2.saldo = 220;
            tabPage1.Text = "Num" + ct1.numero;
            tabPage2.Text = "Num" + ct2.numero;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            button1.Text = "&Consulta\nSaldo";
            button6.Text = "&Consulta\nSaldo";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            string quantia = Interaction.InputBox("Qual a quantia a depositar?", "Depósito");
            ct1.depositar(Convert.ToInt32(quantia));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            string quantia = Interaction.InputBox("Qual a quantia a levantar?", "Levantar");
            ct1.levantar(Convert.ToInt32(quantia));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ct1.ConsultaSaldo();
            textBox1.Text = Convert.ToString(ct1.saldo) + "€";
            textBox1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            string quantia = Interaction.InputBox("Qual a quantia a levantar?", "Levantar");
            ct2.levantar(Convert.ToInt32(quantia));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            string quantia = Interaction.InputBox("Qual a quantia a depositar?", "Depósito");
            ct2.depositar(Convert.ToInt32(quantia));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ct2.ConsultaSaldo();
            textBox2.Text = Convert.ToString(ct2.saldo) + "€";
            textBox2.Enabled = true;
        }
    }
}
