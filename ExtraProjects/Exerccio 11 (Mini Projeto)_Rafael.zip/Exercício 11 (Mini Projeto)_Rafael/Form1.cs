﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercício_06__Mini_Projeto__Rafael_Pietro
{
    public partial class Form1 : Form
    {
        List<Artigo> artigos = new List<Artigo>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Normal");
            comboBox1.Items.Add("Desportiva");
            comboBox1.Items.Add("Scooter");

            comboBox1.SelectedIndex = 0;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        // carros
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double preco = ValidarPreco(textBox3.Text);

                // 2 instâncias
                Carro c1 = new Carro(textBox1.Text, textBox2.Text, preco, textBox4.Text);
                Carro c2 = new Carro(textBox1.Text + " X", textBox2.Text, preco + 1000, textBox4.Text);

                artigos.Add(c1);
                artigos.Add(c2);

                listBox1.Items.Add(c1.MostrarInfo());
                listBox1.Items.Add(c2.MostrarInfo());

                LimparCarro();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // motos
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double preco = ValidarPreco(textBox7.Text);
                string tipo = comboBox1.SelectedItem.ToString();

                Artigo m1, m2;

                if (tipo == "Normal")
                {
                    m1 = new Moto(textBox6.Text, textBox8.Text, preco);
                    m2 = new Moto(textBox6.Text + " X", textBox8.Text, preco + 500);
                }
                else if (tipo == "Desportiva")
                {
                    m1 = new MotoDesportiva(textBox6.Text, textBox8.Text, preco, 600);
                    m2 = new MotoDesportiva(textBox6.Text + " X", textBox8.Text, preco + 1000, 750);
                }
                else
                {
                    m1 = new MotoScooter(textBox6.Text, textBox8.Text, preco, true);
                    m2 = new MotoScooter(textBox6.Text + " X", textBox8.Text, preco + 300, false);
                }

                artigos.Add(m1);
                artigos.Add(m2);

                listBox1.Items.Add(m1.MostrarInfo());
                listBox1.Items.Add(m2.MostrarInfo());

                LimparMoto();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // caminhões
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                double preco = ValidarPreco(textBox11.Text);

                Caminhao c1 = new Caminhao(textBox9.Text, textBox10.Text, preco, textBox12.Text);
                Caminhao c2 = new Caminhao(textBox9.Text + " X", textBox10.Text, preco + 2000, textBox12.Text);

                artigos.Add(c1);
                artigos.Add(c2);

                listBox1.Items.Add(c1.MostrarInfo());
                listBox1.Items.Add(c2.MostrarInfo());

                LimparCaminhao();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // validação
        private double ValidarPreco(string texto)
        {
            if (!double.TryParse(texto, out double preco) || preco <= 0)
            {
                textBox3.Clear();
                textBox7.Clear();
                textBox11.Clear();
                throw new Exception("Preço inválido!");
            }
            return preco;
        }

        private void LimparCarro()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }

        private void LimparMoto()
        {
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
        }

        private void LimparCaminhao()
        {
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void tabPage2_Click(object sender, EventArgs e) { }
        private void label13_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }
        private void label15_Click(object sender, EventArgs e) { }
        private void label14_Click(object sender, EventArgs e) { }
        private void textBox16_TextChanged(object sender, EventArgs e) { }
        private void textBox15_TextChanged(object sender, EventArgs e) { }
        private void textBox14_TextChanged(object sender, EventArgs e) { }
        private void textBox13_TextChanged(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }
        private void label12_Click(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void textBox12_TextChanged(object sender, EventArgs e) { }
        private void textBox11_TextChanged(object sender, EventArgs e) { }
        private void textBox10_TextChanged(object sender, EventArgs e) { }
        private void textBox9_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void textBox4_TextChanged(object sender, EventArgs e) { }
    }
}