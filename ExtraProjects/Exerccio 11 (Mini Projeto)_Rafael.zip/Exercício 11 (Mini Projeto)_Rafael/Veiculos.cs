﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_06__Mini_Projeto__Rafael_Pietro
{
    public abstract class Artigo
    {
        private string marca;
        private string modelo;
        private double preco;

        public string Marca
        {
            get => marca;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Marca inválida!");
                marca = value;
            }
        }

        public string Modelo
        {
            get => modelo;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Modelo inválido!");
                modelo = value;
            }
        }

        public double Preco
        {
            get => preco;
            set
            {
                if (value <= 0)
                    throw new Exception("Preço inválido!");
                preco = value;
            }
        }

        public Artigo(string marca, string modelo, double preco)
        {
            Marca = marca;
            Modelo = modelo;
            Preco = preco;
        }

        public abstract string MostrarInfo();
    }

    public class Carro : Artigo
    {
        private string tipo;

        public string Tipo
        {
            get => tipo;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Tipo inválido!");
                tipo = value;
            }
        }

        public Carro(string marca, string modelo, double preco, string tipo)
            : base(marca, modelo, preco)
        {
            Tipo = tipo;
        }

        public override string MostrarInfo()
        {
            return $"CARRO - {Marca} {Modelo} - {Preco:F2}€ | Tipo: {Tipo}";
        }
    }

    public class Moto : Artigo
    {
        public Moto(string marca, string modelo, double preco)
            : base(marca, modelo, preco) { }

        public override string MostrarInfo()
        {
            return $"MOTO NORMAL - {Marca} {Modelo} - {Preco:F2}€";
        }
    }

    public class MotoDesportiva : Moto
    {
        public int Cilindrada { get; set; }

        public MotoDesportiva(string marca, string modelo, double preco, int cilindrada)
            : base(marca, modelo, preco)
        {
            Cilindrada = cilindrada;
        }

        public override string MostrarInfo()
        {
            return $"MOTO DESPORTIVA - {Marca} {Modelo} - {Preco:F2}€ | {Cilindrada}cc";
        }
    }

    public class MotoScooter : Moto
    {
        public bool TemArranqueEletrico { get; set; }

        public MotoScooter(string marca, string modelo, double preco, bool arranque)
            : base(marca, modelo, preco)
        {
            TemArranqueEletrico = arranque;
        }

        public override string MostrarInfo()
        {
            return $"MOTO SCOOTER - {Marca} {Modelo} - {Preco:F2}€ | Arranque: {(TemArranqueEletrico ? "Sim" : "Não")}";
        }
    }

    public class Caminhao : Artigo
    {
        private string tipo;

        public string Tipo
        {
            get => tipo;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Tipo inválido!");
                tipo = value;
            }
        }

        public Caminhao(string marca, string modelo, double preco, string tipo)
            : base(marca, modelo, preco)
        {
            Tipo = tipo;
        }

        public override string MostrarInfo()
        {
            return $"CAMINHÃO - {Marca} {Modelo} - {Preco:F2}€ | Tipo: {Tipo}";
        }
    }
}