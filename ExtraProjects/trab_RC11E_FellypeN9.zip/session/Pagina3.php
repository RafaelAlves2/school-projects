<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menus.css">
    <title>Assinatura</title>
</head>
<body>

    <?php
    include("header.php");
    ?>

     <main class="form-container">
        <h1><em>Seja um Sócio-Torcedor!</em></h1>
        <p>Preencha o formulário abaixo e junte-se à família Remo </p>

        <form id="socioForm">
            <label for="nome">Nome completo:</label>
            <input type="text" id="nome" name="nome" required placeholder="Ex: Fellype Alves">

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required placeholder="Ex: Fellype@gmail.com">

            <label for="telefone">Telefone:</label>
            <input type="tel" id="telefone" name="telefone" required placeholder="Ex: (17) 99999-9999">

            <label for="endereco">Endereço:</label>
            <input type="text" id="endereco" name="endereco" required placeholder="Rua, número, bairro">

            <label for="plano">Plano desejado:</label>
            <select id="plano" name="plano" required>
                <option value="">Selecione um plano</option>
                <option value="ouro">Plano Ouro - R$ 49,90/mês</option>
                <option value="prata">Plano Prata - R$ 29,90/mês</option>
                <option value="bronze">Plano Bronze - R$ 14,90/mês</option>
            </select>

            <button type="submit">Enviar</button>
        </form>

        <p id="mensagem" class="mensagem"></p>
    </main>

    <!-- JAVASCRIPT PARA MOSTRAR UMA MENSAGEM -->
    <script>
        const form = document.getElementById('socioForm');
        const mensagem = document.getElementById('mensagem');

        form.addEventListener('submit', function(event) {
            event.preventDefault(); 

            const nome = document.getElementById('nome').value;
            const plano = document.getElementById('plano').value;

            //Estrutura de decisão para validar o formulário
            if (nome && plano) {
                mensagem.innerHTML = `🎉 Bem-vindo, <strong>${nome}</strong>!<br>
                Você escolheu o <strong>${plano.toUpperCase()}</strong> e agora faz parte do Clube do Remo! 🦁🔵⚪🏆`;
                mensagem.style.display = 'block';
                form.reset();
            } else {
                mensagem.innerText = 'Por favor, preencha todos os campos!';
                mensagem.style.display = 'block';
                mensagem.style.color = 'red';
            }
        });
    </script>
 
</body>
</html>