<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERRO - Clube do Remo</title>
    <link rel="stylesheet" href="error.css">
    <link rel="stylesheet" href="erroA.css">
</head>
<body>
    <!-- Logo do Clube do Remo -->
    <div class="clube-logo">
        <img src="escudo.png" alt="Escudo do Clube do Remo">
        <span>Clube do Remo</span>
    </div>

    <!-- Conteúdo de Erro -->
    <div class="error-container">
        <div class="error-title">
            <i class="fas fa-exclamation-triangle error-icon"></i>
            <h2>Nome ou Passaporte errado!!!</h2>
        </div>
        
        <div class="error-message">
            <p>As credenciais introduzidas não são válidas. Por favor, verifique o nome de utilizador e a password e tente novamente.</p>
        </div>
        
        <div class="error-details">
            <p>Possíveis causas:</p>
            <ul>
                <li>Nome de utilizador incorreto</li>
                <li>Password incorreta</li>
                <li>Caracteres maiúsculas/minúsculas incorretas</li>
            </ul>
        </div>
        
        <div class="button-container">
            <form action="index.php">
                <button type="submit" class="back-button">
                    <i class="fas fa-arrow-left"></i> Voltar à Página Inicial
                </button>
            </form>
        </div>
    </div>
</body>
</html>