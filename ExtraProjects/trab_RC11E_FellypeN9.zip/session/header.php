<html>
    <head>
        <title> Titulo </title>
        <link rel="stylesheet" href="menus.css">
    </head>
    <body>
        <nav id="menu">
        <div class="logo">
            <img src="escudo.png" alt="Logo do  Clube do Remo">
            <span>Clube do Remo</span>
        </div>
        <ul>
            <li><a href="pag_privada.php" class="active">Início</a></li>
            <li><a href="Pagina1.php">História</a></li>
            <li><a href="Pagina2.php">Elenco</a></li>
            <li><a href="Pagina3.php">Sócio-Torcedor</a></li>
            <li><a href="logout.php">Encerrar Sessão</a></li>
        </ul>
    </nav>
