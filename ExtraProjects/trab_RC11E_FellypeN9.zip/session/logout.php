<?php

    //Medida de segurança para encerrar acesso do usuário
    session_start();
    session_destroy(); // Remove todos os dados da sessão
    header("Location: index.php"); // Redireciona para página inicial
    exit();
?>