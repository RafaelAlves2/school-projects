<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menus.css">
    <link rel="stylesheet" href="pag2.css">
    <title>Elenco Completo do mirassol</title>
</head>
<body>

    <?php
    include("header.php");
    ?>

    <main class="elenco-container">
        <h1><em>Melhores Jogadores – Temporada 2025</em></h1>

        <!-- TABELA DO ELENCO-->
        <table>
            <thead>
                <tr>
                    <th>N°</th>
                    <th>Jogador</th>
                    <th>Posição</th>
                    <th>Partidas</th>
                    <th>Gols</th>
                    <th>Assistências</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>32</td><td>Pedro Rocha</td><td>Atacante</td><td>44</td><td>19</td><td>8</td></tr>
                <tr><td>88</td><td>Marcelo Rangel</td><td>Goleiro</td><td>49</td><td>0</td><td>0</td></tr>
                <tr><td>31</td><td>Alex Manga</td><td>Atacante</td><td>31</td><td>4</td><td>2</td></tr>
                <tr><td>32</td><td>Caio Vinícius</td><td>Meio-Campista</td><td>32</td><td>6</td><td>2</td></tr>
                <tr><td>31</td><td>Dodô</td><td>Meio-Campista</td><td>19</td><td>3</td><td>3</td></tr>
                <tr><td>3</td><td>Marllon</td><td>Zagueiro</td><td>42</td><td>3</td><td>0</td></tr>
                <tr><td>99</td><td>Carlinhos</td><td>Atacante</td><td>26</td><td>7</td><td>0</td></tr>
                <tr><td>22</td><td>Régis</td><td>Meio-Campista</td><td>26</td><td>1</td><td>2</td></tr>
                <tr><td>11</td><td>Nicolás Ferreira</td><td>Meio-Campista</td><td>39</td><td>3</td><td>5</td></tr>
                <tr><td>27</td><td>Kayke</td><td>Zagueiro</td><td>21</td><td>1</td><td>1</td></tr>
                <tr><td>2</td><td>João Lucas</td><td>Lateral-Direito</td><td>20</td><td>1</td><td>0</td></tr>
            </tbody>
        </table>

        <p class="nota"><u>* Estatísticas aproximadas para novembro de 2025. Fonte: flashscore.</u></p>     <!-- Formatação de texto 3 -->  

        <!-- LISTA DO ELENCO -->
        <h2>Elenco completo</h2>
        <ul class="lista-elenco">  <!-- Formatação avançada 1 -->
            <li>Marcelo Rangel – Goleiro</li>
            <li>Marllon – Zagueiro</li>
            <li>Reynaldo – Zagueiro</li>
            <li>Cristian Tassano – Zagueiro</li>
            <li>Léo – Lateral-Esquerdo</li>
            <li>Jorge – Lateral-Esquerdo</li>
            <li>Sávio – Lateral-Direito</li>
            <li>João Lucas – Lateral-Direito</li>
            <li>Zé Ricardo – Meio-Campista</li>
            <li>Dodô – Meio-Campista</li>
            <li>Régis – Meio-Campista</li>
            <li>Gabriel – Meio-Campista</li>
            <li>Nicolás Ferreira – Meio-Campista</li>
            <li>Caio Vinícius – Meio-Campista</li>
            <li>Carlinhos – Atacante</li>
            <li>Alex Manga – Atacante</li>
            <li>Pedro Rocha – Atacante</li>
            <li>Rafael Monti – Atacante</li>
        </ul>

    </main>
    
</body>
</html>