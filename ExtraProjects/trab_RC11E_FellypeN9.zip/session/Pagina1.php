<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menus.css">
    <link rel="stylesheet" href="pag1.css">
    <title>História do Remo</title>
</head>
<body>
    
     <?php
    include("header.php");
    ?>

    <main class="historia-container">
        <h1><em>História do Cube do Remo</em></h1>     

        <section class="bloco">
            <img src="time.png" alt="Primeiro time do Clube do Remo">    
            <div class="texto">
                <h2>As Origens</h2>    
                <p>     
                    O Clube do Remo foi fundado em 5 de fevereiro de 1905, na cidade de Belém do Pará. Surgiu inicialmente como um clube dedicado ao remo, esporte que dava nome à instituição. Com o passar dos anos, o futebol ganhou destaque e se tornou a principal paixão do clube,
                    representando com orgulho o povo paraense.
                </p>
            </div>
        </section>

        <section class="bloco invertido">
            <img src="bandeira.png" alt="Cores azul e branca do Clube do Remo">
            <div class="texto">
                <h2>As Cores e o Símbolo</h2>
                <p>
                    As cores azul e branca simbolizam tradição, lealdade e grandeza. O leão, mascote do clube, representa força, bravura e espírito de luta. Conhecido como “Leão Azul”, o Remo carrega uma das identidades mais marcantes do futebol brasileiro, especialmente na Região Norte.
                </p>
            </div>
        </section>

        <section class="bloco">
           <img src="campeao.png" alt="Time do Remo em competições nacionais">
            <div class="texto">
                <h2>A Ascensão</h2>
                <p>
                    O Clube do Remo construiu uma trajetória vitoriosa ao longo do século XX,
                    conquistando títulos estaduais e se firmando como uma das maiores forças do futebol paraense. O clube também teve participações importantes em competições
                    nacionais, ganhando respeito em todo o país.
                </p>
        </section>

        <section class="bloco invertido">
            <img src="base.png" alt="Categoria de base do Clube do Remo">
            <div class="texto">
                <h2>Reestruturação e Base Forte</h2>
                <p>
                    Ao longo dos anos, o Remo passou por processos de reestruturação administrativa
                    e esportiva, investindo na formação de atletas e no fortalecimento de suas
                    categorias de base. Essa visão contribuiu para revelar talentos e manter o clube
                    competitivo mesmo diante de grandes desafios.
                </p>
            </div>
        </section>

        <section class="bloco">
           <img src="atual.png" alt="Remo em competições nacionais atualmente">
            <div class="texto">
                <h2>Os Novos Tempos</h2>
                <p>    
                    Nos últimos anos, o Clube do Remo buscou se reerguer no cenário nacional,
                    retornando às divisões superiores do Campeonato Brasileiro. Com o apoio
                    apaixonado de sua torcida, o clube segue lutando para reconquistar seu espaço
                    entre os grandes do futebol brasileiro.
                </p>
            </div>
        </section>

        <section class="bloco invertido">
            <img src="estadio.png"  alt="Estádio Baenão">
            <div class="texto">
                  <h2>O Baenão e o Futuro</h2>
                <p>
                    O Estádio Evandro Almeida, conhecido como <em>“Baenão”</em>,
                    é um símbolo histórico do Clube do Remo. Palco de jogos memoráveis,
                    representa a paixão da torcida azulina. Com tradição, força e esperança,
                    o Remo segue escrevendo sua história e levando o nome do Pará para todo o Brasil.
                </p>
            </div>
        </section>
    </main>


</body>
</html>