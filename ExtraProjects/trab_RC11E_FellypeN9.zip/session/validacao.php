<?php
session_start();

//Credenciais válidas: usuário "Fellype", senha "2026"
//Redireciona para área privada ou página de erro conforme resultado
//estrutura de decisão para validar o login 
if (isset($_POST["nome"]) && isset($_POST["Password"])) {

    // Cookies: armazenam o último login por 60 segundos para preenchimento automático
    setcookie("ultimo_nome", $_POST["nome"], time() + 60);
    setcookie("ultima_Password", $_POST["Password"], time() + 60);

    // Verificação das credenciais 
    if ($_POST["nome"] == "Fellype" && $_POST["Password"] == "2026") {
        $_SESSION["nome"] = "Fellype";
        $_SESSION["Password"] = "2026";

        header("Location: pag_privada.php");
        exit();

        // Credenciais inválidas: redireciona para página de erro
    } else {
        header("Location: erro.php");
        exit();
    }

    // Acesso direto ao script sem dados do formulário
} else {
    header("Location: index.php");
    exit();
}
