<?php
session_start();

// Controle de acesso: verifica se variáveis de sessão existem
if (!isset($_SESSION["nome"]) && !isset($_SESSION["Password"])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menus.css">
    <link rel="stylesheet" href="pagpriv.css">
    <title>Página Principal</title>
</head>
<body>

    <?php
    include("header.php");
    ?>

    <!-- CONTEÚDO PRINCIPAL -->
    <main class="home-container">
        <section class="boas-vindas">
            <h1><em> Bem-vindo <?php echo $_SESSION["nome"]; ?> ao site oficial do Futebol Clube do Remo!</em></h1>  
            <p>O Leão Azul da Amazônia te dá as boas-vindas ao site oficial do Clube do Remo. <br>
            <strong>Fique por dentro da história, do elenco e torne-se um sócio-torcedor!</strong></p>  
        </section>

        <section class="foto-elenco">
            <img src="elenc1.png" alt="Elenco atual ">
            <figcaption>...</figcaption>
        </section>

        <section class="jogos">
    <div class="jogos-container">
        <!-- Últimos jogos -->
        <div class="ultimos-jogos">
            <h2>Últimos 5 Jogos</h2>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="resultado">2 - 1</span>
                <img src="aguia.png" alt="Aguia de Marabá" class="escudo">
            </div>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="resultado">3 - 1</span>
                <img src="goias.png" alt="Goiás" class="escudo">
            </div>
            <div class="jogo">
                <img src="avai.png" alt="Avaí" class="escudo">
                <span class="resultado">3 - 1</span>
                <img src="remo01.png" alt="Remo" class="escudo">
            </div>
            <div class="jogo">
                <img src="novo.png" alt="Novorizontino" class="escudo">
                <span class="resultado">1 - 1</span>
                <img src="remo01.png" alt="Remo" class="escudo">
            </div>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="resultado">1 - 1</span>
                <img src="chape.png" alt="Chapecoense" class="escudo">
            </div>
        </div>

        <!-- PRÓXIMOS JOGOS -->
        <div class="proximos-jogos">
            <h2>Próximos 5 Jogos</h2>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="data">24/01</span>
                <img src="braga.png" alt="Bragantino-PA" class="escudo">
            </div>
            <div class="jogo">
                <img src="vitoria.png" alt="Vitória" class="escudo">
                <span class="data">28/01</span>
                <img src="remo01.png" alt="Remo" class="escudo">
            </div>
             <div class="jogo">
                <img src="saof.png" alt="São Francisco-PA" class="escudo">
                <span class="data">31/01</span>
                <img src="remo01.png" alt="Remo" class="escudo">
            </div>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="data">3/02</span>
                <img src="aguia.png" alt="Aguia de Marabá" class="escudo">
            </div>
            <div class="jogo">
                <img src="remo01.png" alt="Remo" class="escudo">
                <span class="data">5/02</span>
                <img src="mira.png" alt="Mirassol" class="escudo">
            </div>
        </div>
    </div>
</section>
    </main>

</body>
</html>