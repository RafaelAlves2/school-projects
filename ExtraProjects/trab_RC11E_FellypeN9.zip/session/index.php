<?php

if(!isset($_COOKIE["ultimo_nome"])) {
    setcookie("ultimo_nome", "", time() + 60);
}

if(!isset($_COOKIE["ultima_Password"])) {
    setcookie("ultima_Password", "", time() + 60);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial - Clube do Remo</title>
    <link rel="stylesheet" href="senha.css">
</head>
<body>
    <!-- Cabeçalho -->
    <header>
        <div class="logo-container">
            <img src="escudo.png" alt="Escudo do Clube do Remo">
            <div>
                <h1>Clube do Remo</h1>
                <p class="tagline">O Mais Querido do Pará</p>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main>
        <section class="welcome-section">
            <h2>Bem-vindo ao Portal do Clube do Remo</h2>
            <p>Entre com seu nome e senha para acessar o conteúdo exclusivo do Leão Azul.</p>
        </section>

        <!-- Formulário de Login -->
        <div class="login-form-container">
            <h2>Introduza o seu nome e sua password</h2>

            <form method="post" action="validacao.php">
                <div class="input-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" required 
                        value="<?php echo $_COOKIE["ultimo_nome"] ?? ''; ?>"
                        placeholder="Fellype">
                </div>
                
                <div class="input-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="Password" required
                        value="<?php echo $_COOKIE["ultima_Password"] ?? ''; ?>"
                        placeholder="2026">
                </div>
                
                <input type="submit" value="Entrar" class="submit-btn">
            </form>
        </div>
    </main>

    <!-- Rodapé -->
    <footer>
        <div class="footer-content">
            <p>Clube do Remo - Fundado em 1905</p>
            <p>O maior campeão do Norte do Brasil</p>
            <?php
            include("footer.php");
            ?>
        </div>
    </footer>

</body>
</html>