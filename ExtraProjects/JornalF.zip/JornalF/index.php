<?php
include_once 'includes/header.php';
include_once 'basedados/bsdados.php';

$query = "SELECT id, titulo, conteudo, imagem, data_publicacao, autor FROM noticias ORDER BY data_publicacao DESC";
$resultado = $conexao->query($query);
?>

<div class="container">
    <h4 class="light">Últimas Notícias</h4>
    <hr>
    <div class="row">
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($noticia = $resultado->fetch_assoc()): ?>
                <div class="col s12 m6 l4">
                    <div class="card hoverable">
                        <div class="card-image">
                            <?php if (!empty($noticia['imagem'])): ?>
                                <img src="uploads/<?php echo $noticia['imagem']; ?>" alt="<?php echo $noticia['titulo']; ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <img src="imagens/sem-imagem.jpg" alt="Sem imagem">
                            <?php endif; ?>
                        </div>
                        <div class="card-content">
                            <span class="card-title"><?php echo $noticia['titulo']; ?></span>
                            <p><?php echo substr($noticia['conteudo'], 0, 150) . '...'; ?></p>
                            <p><small>Publicado em <?php echo date('d/m/Y', strtotime($noticia['data_publicacao'])); ?> por <?php echo $noticia['autor']; ?></small></p>
                        </div>
                        <div class="card-action">
                            <a href="noticia.php?id=<?php echo $noticia['id']; ?>">Ler mais</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Nenhuma notícia encontrada.</p>
        <?php endif; ?>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>