<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO utilizadores (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
    if ($conexao->query($sql)) {
        header('Location: utilizadores.php?msg=Utilizador inserido!');
        exit;
    } else {
        $erro = "Erro: " . $conexao->error;
    }
}
?>

<h4 class="light">Inserir Utilizador</h4>
<hr>
<?php if (isset($erro)) echo '<div class="red white-text center">'.$erro.'</div>'; ?>
<form action="" method="POST">
    <div class="input-field">
        <input type="text" name="nome" id="nome" required>
        <label for="nome">Nome</label>
    </div>
    <div class="input-field">
        <input type="email" name="email" id="email" required>
        <label for="email">Email</label>
    </div>
    <div class="input-field">
        <input type="password" name="senha" id="senha" required>
        <label for="senha">Senha</label>
    </div>
    <button type="submit" class="btn green">Inserir</button>
    <a href="utilizadores.php" class="btn red">Cancelar</a>
</form>

<?php include_once 'includes/admin_footer.php'; ?>