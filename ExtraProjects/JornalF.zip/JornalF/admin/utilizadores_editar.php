<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: utilizadores.php');
    exit;
}

$resultado = $conexao->query("SELECT * FROM utilizadores WHERE id = $id");
if ($resultado->num_rows == 0) {
    header('Location: utilizadores.php');
    exit;
}
$user = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = $_POST['senha'];
    if (!empty($senha)) {
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $sql = "UPDATE utilizadores SET nome='$nome', email='$email', senha='$senha_hash' WHERE id=$id";
    } else {
        $sql = "UPDATE utilizadores SET nome='$nome', email='$email' WHERE id=$id";
    }
    if ($conexao->query($sql)) {
        header('Location: utilizadores.php?msg=Utilizador atualizado!');
        exit;
    } else {
        $erro = "Erro: " . $conexao->error;
    }
}
?>

<h4 class="light">Editar Utilizador</h4>
<hr>
<?php if (isset($erro)) echo '<div class="red white-text center">'.$erro.'</div>'; ?>
<form action="" method="POST">
    <div class="input-field">
        <input type="text" name="nome" id="nome" value="<?php echo $user['nome']; ?>" required>
        <label for="nome" class="active">Nome</label>
    </div>
    <div class="input-field">
        <input type="email" name="email" id="email" value="<?php echo $user['email']; ?>" required>
        <label for="email" class="active">Email</label>
    </div>
    <div class="input-field">
        <input type="password" name="senha" id="senha">
        <label for="senha" class="active">Nova senha (deixe em branco para manter a atual)</label>
    </div>
    <button type="submit" class="btn blue">Atualizar</button>
    <a href="utilizadores.php" class="btn red">Cancelar</a>
</form>

<?php include_once 'includes/admin_footer.php'; ?>