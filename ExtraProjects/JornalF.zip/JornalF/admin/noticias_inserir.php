<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';
include_once '../basedados/funcoes.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $conexao->real_escape_string($_POST['titulo']);
    $conteudo = $conexao->real_escape_string($_POST['conteudo']);
    $autor = $conexao->real_escape_string($_POST['autor']);
    $imagem_nome = null;

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagem_nome = uploadImagem($_FILES['imagem'], '../uploads/');
        if (!$imagem_nome) {
            $erro = "Erro ao fazer upload da imagem. Extensões permitidas: jpg, jpeg, png, gif.";
        }
    }

    if (!isset($erro)) {
        $sql = "INSERT INTO noticias (titulo, conteudo, imagem, autor) VALUES ('$titulo', '$conteudo', '$imagem_nome', '$autor')";
        if ($conexao->query($sql)) {
            header('Location: noticias.php?msg=Notícia inserida com sucesso!');
            exit;
        } else {
            $erro = "Erro ao inserir: " . $conexao->error;
        }
    }
}
?>

<h4 class="light">Inserir Notícia</h4>
<hr>
<?php if (isset($erro)) echo '<div class="red white-text center" style="padding:5px;">'.$erro.'</div>'; ?>
<form action="" method="POST" enctype="multipart/form-data">
    <div class="input-field">
        <input type="text" name="titulo" id="titulo" required>
        <label for="titulo">Título</label>
    </div>
    <div class="input-field">
        <textarea name="conteudo" id="conteudo" class="materialize-textarea" required></textarea>
        <label for="conteudo">Conteúdo</label>
    </div>
    <div class="input-field">
        <input type="text" name="autor" id="autor" required>
        <label for="autor">Autor</label>
    </div>
    <div class="file-field input-field">
        <div class="btn">
            <span>Imagem</span>
            <input type="file" name="imagem" accept="image/*">
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" type="text" placeholder="Selecione uma imagem (opcional)">
        </div>
    </div>
    <button type="submit" class="btn green">Inserir</button>
    <a href="noticias.php" class="btn red">Cancelar</a>
</form>

<?php include_once 'includes/admin_footer.php'; ?>