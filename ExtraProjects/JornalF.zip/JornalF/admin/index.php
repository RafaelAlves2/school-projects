<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$total_noticias = $conexao->query("SELECT COUNT(*) AS total FROM noticias")->fetch_assoc()['total'];
$total_comentarios = $conexao->query("SELECT COUNT(*) AS total FROM comentarios")->fetch_assoc()['total'];
$total_utilizadores = $conexao->query("SELECT COUNT(*) AS total FROM utilizadores")->fetch_assoc()['total'];
?>

<h4 class="light">Dashboard</h4>
<hr>
<div class="row">
    <div class="col s12 m4">
        <div class="card blue-grey darken-1">
            <div class="card-content white-text">
                <span class="card-title">Notícias</span>
                <h3><?php echo $total_noticias; ?></h3>
            </div>
            <div class="card-action">
                <a href="noticias.php">Ver todas</a>
            </div>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card blue-grey darken-1">
            <div class="card-content white-text">
                <span class="card-title">Comentários</span>
                <h3><?php echo $total_comentarios; ?></h3>
            </div>
            <div class="card-action">
                <a href="comentarios.php">Ver todos</a>
            </div>
        </div>
    </div>
    <div class="col s12 m4">
        <div class="card blue-grey darken-1">
            <div class="card-content white-text">
                <span class="card-title">Utilizadores</span>
                <h3><?php echo $total_utilizadores; ?></h3>
            </div>
            <div class="card-action">
                <a href="utilizadores.php">Ver todos</a>
            </div>
        </div>
    </div>
</div>

<?php include_once 'includes/admin_footer.php'; ?>