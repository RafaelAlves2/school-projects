<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
<div class="container">
    <h4>Login</h4>
    <form method="POST">
        <input type="text" name="email" placeholder="Email = admin@jornalfutebol.com" required>
        <input type="password" name="senha" placeholder="Senha = admin123" required>
        <button type="submit" class="btn">Entrar</button>
    </form>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        include_once '../basedados/bsdados.php';
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $sql = "SELECT * FROM utilizadores WHERE email = '$email'";
        $result = $conexao->query($sql);
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($senha, $user['senha'])) {
                $_SESSION['admin_logado'] = true;
                echo "<div class='green white-text'>Login bem-sucedido! Redirecionando...</div>";
                header('refresh:2; url=index.php');
            } else {
                echo "<div class='red white-text'>Senha errada</div>";
            }
        } else {
            echo "<div class='red white-text'>Email não encontrado</div>";
        }
    }
    ?>
</div>
</body>
</html>