<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if ($id) {
    $conexao->query("DELETE FROM comentarios WHERE id = $id");
}
header('Location: comentarios.php?msg=Comentário apagado!');
exit;
?>