<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

if (isset($_GET['msg'])) {
    echo '<div class="green white-text center" style="padding:5px;">' . $_GET['msg'] . '</div>';
}

$resultado = $conexao->query("SELECT c.*, n.titulo as noticia_titulo FROM comentarios c JOIN noticias n ON c.noticia_id = n.id ORDER BY c.data_comentario DESC");
?>

<h4 class="light">Comentários</h4>
<hr>
<table class="striped">
    <thead>
        <tr>
            <th>Notícia</th>
            <th>Nome</th>
            <th>Comentário</th>
            <th>Data</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['noticia_titulo']; ?></td>
                    <td><?php echo $row['nome']; ?></td>
                    <td><?php echo substr($row['comentario'], 0, 50) . (strlen($row['comentario']) > 50 ? '...' : ''); ?></td>
                    <td><?php echo date('d/m/Y H:i', strtotime($row['data_comentario'])); ?></td>
                    <td>
                        <a href="comentarios_editar.php?id=<?php echo $row['id']; ?>" class="btn-small blue">Editar</a>
                        <a href="comentarios_apagar.php?id=<?php echo $row['id']; ?>" class="btn-small red" onclick="return confirm('Tem certeza?')">Apagar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5">Nenhum comentário encontrado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include_once 'includes/admin_footer.php'; ?>