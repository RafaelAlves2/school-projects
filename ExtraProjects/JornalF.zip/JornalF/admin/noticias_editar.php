<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';
include_once '../basedados/funcoes.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: noticias.php');
    exit;
}

$resultado = $conexao->query("SELECT * FROM noticias WHERE id = $id");
if ($resultado->num_rows == 0) {
    header('Location: noticias.php');
    exit;
}
$noticia = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $conexao->real_escape_string($_POST['titulo']);
    $conteudo = $conexao->real_escape_string($_POST['conteudo']);
    $autor = $conexao->real_escape_string($_POST['autor']);
    $imagem_nome = $noticia['imagem']; // manter antiga se não enviar nova

    if (isset($_FILES['nova_imagem']) && $_FILES['nova_imagem']['error'] == 0) {
        $novo_nome = uploadImagem($_FILES['nova_imagem'], '../uploads/');
        if ($novo_nome) {
            // Apagar imagem antiga se existir
            if (!empty($noticia['imagem']) && file_exists('../uploads/' . $noticia['imagem'])) {
                unlink('../uploads/' . $noticia['imagem']);
            }
            $imagem_nome = $novo_nome;
        } else {
            $erro = "Erro ao fazer upload da nova imagem.";
        }
    }

    if (!isset($erro)) {
        $sql = "UPDATE noticias SET titulo='$titulo', conteudo='$conteudo', autor='$autor', imagem='$imagem_nome' WHERE id=$id";
        if ($conexao->query($sql)) {
            header('Location: noticias.php?msg=Notícia atualizada com sucesso!');
            exit;
        } else {
            $erro = "Erro ao atualizar: " . $conexao->error;
        }
    }
}
?>

<h4 class="light">Editar Notícia</h4>
<hr>
<?php if (isset($erro)) echo '<div class="red white-text center" style="padding:5px;">'.$erro.'</div>'; ?>
<form action="" method="POST" enctype="multipart/form-data">
    <div class="input-field">
        <input type="text" name="titulo" id="titulo" value="<?php echo $noticia['titulo']; ?>" required>
        <label for="titulo" class="active">Título</label>
    </div>
    <div class="input-field">
        <textarea name="conteudo" id="conteudo" class="materialize-textarea" required><?php echo $noticia['conteudo']; ?></textarea>
        <label for="conteudo" class="active">Conteúdo</label>
    </div>
    <div class="input-field">
        <input type="text" name="autor" id="autor" value="<?php echo $noticia['autor']; ?>" required>
        <label for="autor" class="active">Autor</label>
    </div>
    <?php if (!empty($noticia['imagem'])): ?>
        <div>
            <p>Imagem atual:</p>
            <img src="../uploads/<?php echo $noticia['imagem']; ?>" style="max-width: 200px; max-height: 200px;">
        </div>
    <?php endif; ?>
    <div class="file-field input-field">
        <div class="btn">
            <span>Nova Imagem (opcional)</span>
            <input type="file" name="nova_imagem" accept="image/*">
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" type="text" placeholder="Selecione para substituir">
        </div>
    </div>
    <button type="submit" class="btn blue">Atualizar</button>
    <a href="noticias.php" class="btn red">Cancelar</a>
</form>

<?php include_once 'includes/admin_footer.php'; ?>