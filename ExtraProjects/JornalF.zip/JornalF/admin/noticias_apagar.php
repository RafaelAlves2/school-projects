<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if ($id) {
    // Buscar imagem para apagar
    $result = $conexao->query("SELECT imagem FROM noticias WHERE id = $id");
    if ($result->num_rows > 0) {
        $img = $result->fetch_assoc()['imagem'];
        if (!empty($img) && file_exists('../uploads/' . $img)) {
            unlink('../uploads/' . $img);
        }
    }
    $conexao->query("DELETE FROM noticias WHERE id = $id");
}
header('Location: noticias.php?msg=Notícia apagada com sucesso!');
exit;
?>