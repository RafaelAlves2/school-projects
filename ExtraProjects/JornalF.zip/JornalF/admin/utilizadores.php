<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

if (isset($_GET['msg'])) {
    echo '<div class="green white-text center">' . $_GET['msg'] . '</div>';
}

$resultado = $conexao->query("SELECT id, nome, email, data_registo FROM utilizadores ORDER BY id");
?>

<h4 class="light">Utilizadores</h4>
<hr>
<a href="utilizadores_inserir.php" class="btn green">Novo Utilizador</a>
<table class="striped">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Email</th>
            <th>Data Registo</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['nome']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo date('d/m/Y', strtotime($row['data_registo'])); ?></td>
                <td>
                    <a href="utilizadores_editar.php?id=<?php echo $row['id']; ?>" class="btn-small blue">Editar</a>
                    <a href="utilizadores_apagar.php?id=<?php echo $row['id']; ?>" class="btn-small red" onclick="return confirm('Tem certeza?')">Apagar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include_once 'includes/admin_footer.php'; ?>