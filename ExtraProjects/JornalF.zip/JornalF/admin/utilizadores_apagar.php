<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if ($id && $id != $_SESSION['admin_id']) { // não permitir apagar a própria conta
    $conexao->query("DELETE FROM utilizadores WHERE id = $id");
}
header('Location: utilizadores.php?msg=Utilizador apagado (se não era o próprio)!');
exit;
?>