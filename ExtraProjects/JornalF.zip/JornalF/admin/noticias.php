<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

if (isset($_GET['msg'])) {
    echo '<div class="green white-text center" style="padding: 5px;">' . $_GET['msg'] . '</div>';
}

$resultado = $conexao->query("SELECT id, titulo, data_publicacao, autor FROM noticias ORDER BY data_publicacao DESC");
?>

<h4 class="light">Notícias</h4>
<hr>
<a href="noticias_inserir.php" class="btn green">Nova Notícia</a>
<table class="striped">
    <thead>
        <tr>
            <th>Título</th>
            <th>Data</th>
            <th>Autor</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['titulo']; ?></td>
                    <td><?php echo date('d/m/Y', strtotime($row['data_publicacao'])); ?></td>
                    <td><?php echo $row['autor']; ?></td>
                    <td>
                        <a href="noticias_editar.php?id=<?php echo $row['id']; ?>" class="btn-small blue">Editar</a>
                        <a href="noticias_apagar.php?id=<?php echo $row['id']; ?>" class="btn-small red" onclick="return confirm('Tem certeza?')">Apagar</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="4">Nenhuma notícia encontrada.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php include_once 'includes/admin_footer.php'; ?>