<?php

include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: comentarios.php');
    exit;
}

$resultado = $conexao->query("SELECT * FROM comentarios WHERE id = $id");
if ($resultado->num_rows == 0) {
    header('Location: comentarios.php');
    exit;
}
$comentario = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $texto = $conexao->real_escape_string($_POST['comentario']);
    $sql = "UPDATE comentarios SET nome='$nome', comentario='$texto' WHERE id=$id";
    if ($conexao->query($sql)) {
        header('Location: comentarios.php?msg=Comentário atualizado!');
        exit;
    } else {
        $erro = "Erro: " . $conexao->error;
    }
}
?>

<h4 class="light">Editar Comentário</h4>
<hr>
<?php if (isset($erro)) echo '<div class="red white-text center">'.$erro.'</div>'; ?>
<form action="" method="POST">
    <div class="input-field">
        <input type="text" name="nome" id="nome" value="<?php echo $comentario['nome']; ?>" required>
        <label for="nome" class="active">Nome</label>
    </div>
    <div class="input-field">
        <textarea name="comentario" id="comentario" class="materialize-textarea" required><?php echo $comentario['comentario']; ?></textarea>
        <label for="comentario" class="active">Comentário</label>
    </div>
    <button type="submit" class="btn blue">Atualizar</button>
    <a href="comentarios.php" class="btn red">Cancelar</a>
</form>

<?php include_once 'includes/admin_footer.php'; ?>