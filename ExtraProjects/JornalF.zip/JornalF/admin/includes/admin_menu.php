<?php
?>
<nav>
    <div class="nav-wrapper red darken-2">
        <a href="index.php" class="brand-logo center">Admin - Jornal de Futebol</a>
        <ul id="nav-mobile" class="left hide-on-med-and-down">
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="noticias.php">Notícias</a></li>
            <li><a href="comentarios.php">Comentários</a></li>
            <li><a href="utilizadores.php">Utilizadores</a></li>
            <li><a href="logout.php">Sair</a></li>
        </ul>
    </div>
</nav>