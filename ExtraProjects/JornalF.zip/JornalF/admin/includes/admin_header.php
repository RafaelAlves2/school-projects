<?php
session_start();
if (!isset($_SESSION['admin_logado']) || $_SESSION['admin_logado'] !== true) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Jornal de Futebol</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header style="background: #b71c1c;">
    <div class="container">
        <nav>
            <div class="logo">
                <a href="index.php">Admin Jornal de Futebol</a>
                <div class="menu-toggle" id="mobile-menu">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
            <ul class="nav-links" id="nav-links">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="noticias.php">Notícias</a></li>
                <li><a href="comentarios.php">Comentários</a></li>
                <li><a href="utilizadores.php">Utilizadores</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </div>
</header>
<main>
    <div class="container">