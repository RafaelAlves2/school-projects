    </div> <!-- .container -->
</main>
<footer style="background: #b71c1c;">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Área Administrativa - Jornal de Futebol</p>
    </div>
</footer>
<script>
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinks = document.getElementById('nav-links');
    if (mobileMenu) {
        mobileMenu.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
</script>
</body>
</html>