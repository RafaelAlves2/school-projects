<?php

include_once 'includes/header.php';
include_once 'basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: index.php');
    exit;
}

// Buscar notícia
$query = "SELECT * FROM noticias WHERE id = $id";
$resultado = $conexao->query($query);
if ($resultado->num_rows == 0) {
    header('Location: index.php');
    exit;
}
$noticia = $resultado->fetch_assoc();

// Processar comentário se enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comentario'])) {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $comentario = $conexao->real_escape_string($_POST['comentario']);
    $sql = "INSERT INTO comentarios (noticia_id, nome, comentario) VALUES ($id, '$nome', '$comentario')";
    $conexao->query($sql);
    header("Location: noticia.php?id=$id");
    exit;
}

// Buscar comentários
$comentarios = $conexao->query("SELECT * FROM comentarios WHERE noticia_id = $id ORDER BY data_comentario DESC");
?>

<div class="container">
    <h4><?php echo $noticia['titulo']; ?></h4>
    <p><small>Publicado em <?php echo date('d/m/Y H:i', strtotime($noticia['data_publicacao'])); ?> por <?php echo $noticia['autor']; ?></small></p>
    <?php if (!empty($noticia['imagem'])): ?>
        <img src="uploads/<?php echo $noticia['imagem']; ?>" alt="<?php echo $noticia['titulo']; ?>" class="noticia-img">
    <?php endif; ?>
    <p><?php echo nl2br($noticia['conteudo']); ?></p>

    <hr>
    <h5>Comentários</h5>
    <?php if ($comentarios->num_rows > 0): ?>
        <?php while ($com = $comentarios->fetch_assoc()): ?>
            <div class="card-panel grey lighten-4">
                <strong><?php echo $com['nome']; ?></strong> <small><?php echo date('d/m/Y H:i', strtotime($com['data_comentario'])); ?></small>
                <p><?php echo nl2br($com['comentario']); ?></p>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p>Seja o primeiro a comentar!</p>
    <?php endif; ?>

    <hr>
    <h5>Deixe o seu comentário</h5>
    <form action="noticia.php?id=<?php echo $id; ?>" method="POST">
        <div class="input-field">
            <i class="material-icons prefix">account_circle</i>
            <input type="text" name="nome" id="nome" required>
            <label for="nome">Seu nome</label>
        </div>
        <div class="input-field">
            <i class="material-icons prefix">comment</i>
            <textarea name="comentario" id="comentario" class="materialize-textarea" required></textarea>
            <label for="comentario">Comentário</label>
        </div>
        <button type="submit" class="btn blue">Enviar</button>
    </form>
</div>

<?php include_once 'includes/footer.php'; ?>