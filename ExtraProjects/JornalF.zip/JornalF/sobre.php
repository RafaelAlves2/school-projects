<?php
include_once 'includes/header.php';
?>

<div class="container">
    <h4 class="light">Sobre o Jornal de Futebol</h4>
    <hr>
    <p>O Jornal de Futebol é um projeto desenvolvido no âmbito do módulo 7A – Acesso a Bases de Dados via Web. O objetivo é criar um website dinâmico com backend para gestão de conteúdos e frontend para os leitores.</p>
    <p>Este site apresenta notícias sobre futebol, permitindo aos visitantes ler e comentar. A área administrativa permite gerir notícias, comentários e utilizadores.</p>
    <p>Tecnologias utilizadas: HTML, CSS (Materialize), JavaScript, PHP e MySQL.</p>
</div>

<?php include_once 'includes/footer.php'; ?>