<?php
function uploadImagem($arquivo, $pasta_destino = "../uploads/") {
    $nome_original = $arquivo['name'];
    $extensao = strtolower(pathinfo($nome_original, PATHINFO_EXTENSION));
    $extensoes_permitidas = array('jpg', 'jpeg', 'png', 'gif');

    if (!in_array($extensao, $extensoes_permitidas)) {
        return false; // extensão não permitida
    }

    // Gerar nome único
    $novo_nome = uniqid() . '.' . $extensao;
    $caminho_completo = $pasta_destino . $novo_nome;

    if (move_uploaded_file($arquivo['tmp_name'], $caminho_completo)) {
        return $novo_nome; // retorna apenas o nome do ficheiro
    } else {
        return false;
    }
}
?>