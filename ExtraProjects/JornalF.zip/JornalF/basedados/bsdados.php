<?php
$servidor = "localhost";
$utilizador = "root";   // alterar conforme o seu ambiente
$senha_db = "";         // alterar conforme o seu ambiente
$base_dados = "jornal_futebol";

$conexao = new mysqli($servidor, $utilizador, $senha_db, $base_dados);

if ($conexao->connect_error) {
    die("Falha na ligação: " . $conexao->connect_error);
}
?>