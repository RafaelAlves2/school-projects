<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jornal de Futebol</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Font Awesome opcional para ícones (pode remover se não quiser) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
    <div class="container">
        <nav>
            <div class="logo">
                <a href="index.php">Jornal de Futebol</a>
                <div class="menu-toggle" id="mobile-menu">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
            <ul class="nav-links" id="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="sobre.php">Sobre</a></li>
                <?php if (isset($_SESSION['admin_logado']) && $_SESSION['admin_logado'] === true): ?>
                    <li><a href="admin/index.php">Admin</a></li>
                    <li><a href="admin/logout.php">Sair</a></li>
                <?php else: ?>
                    <li><a href="admin/login.php">Login
                    </a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
<main>
    <div class="container">