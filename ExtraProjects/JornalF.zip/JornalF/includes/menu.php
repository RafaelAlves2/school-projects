<nav>
    <div class="nav-wrapper blue darken-3">
        <a href="index.php" class="brand-logo center">Jornal de Futebol</a>
        <ul id="nav-mobile" class="left hide-on-med-and-down">
            <li><a href="index.php">Home</a></li>
            <li><a href="sobre.php">Sobre</a></li>
            <?php if (isset($_SESSION['admin_logado']) && $_SESSION['admin_logado'] === true): ?>
                <li><a href="admin/index.php">Admin</a></li>
                <li><a href="admin/logout.php">Sair</a></li>
            <?php else: ?>
                <li><a href="admin/login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>