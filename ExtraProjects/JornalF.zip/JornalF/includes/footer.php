    </div> <!-- .container -->
</main>
<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> Jornal de Futebol - Todos os direitos reservados.</p>
    </div>
</footer>
<script>
    // Menu mobile toggle
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinks = document.getElementById('nav-links');
    if (mobileMenu) {
        mobileMenu.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
</script>
</body>
</html>