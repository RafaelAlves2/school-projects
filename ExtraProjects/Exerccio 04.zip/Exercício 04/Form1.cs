﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Exercício_04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Apenas valores pares
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = Convert.ToInt32(textBox1.Text);

                if (numero % 2 != 0)
                    throw new Exception("Só são permitidos números pares.");

                MessageBox.Show("Número válido!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce apenas números.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Valor dentro do intervalo
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = Convert.ToInt32(textBox6.Text);

                if (numero < 10 || numero > 20)
                    throw new ArgumentOutOfRangeException("O valor deve estar entre 10 e 20.");

                MessageBox.Show("Valor dentro do intervalo.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce apenas números.");
            }
            catch (ArgumentOutOfRangeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // Mês
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int mes = Convert.ToInt32(textBox9.Text);

                if (mes < 1 || mes > 12)
                    throw new Exception("O mês deve estar entre 1 e 12.");

                MessageBox.Show("Mês válido!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce um número válido.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // d) Mês throw fora do try
        private void button4_Click(object sender, EventArgs e)
        {
            int mes;

            try
            {
                mes = Convert.ToInt32(textBox12.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce um número válido.");
                return;
            }

            if (mes < 1 || mes > 12)
                throw new ArgumentOutOfRangeException("O mês deve estar entre 1 e 12.");

            MessageBox.Show("Mês válido!");
        }


        // divisão por zero
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox8.Text);
                int b = Convert.ToInt32(textBox7.Text);

                int resultado = a / b;

                MessageBox.Show("Resultado: " + resultado);
            }
            catch (DivideByZeroException)
            {
                MessageBox.Show("Não podes dividir por zero.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Introduce apenas números.");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

    }
}