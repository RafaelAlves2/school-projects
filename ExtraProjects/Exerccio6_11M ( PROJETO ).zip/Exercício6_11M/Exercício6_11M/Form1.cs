﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic;

namespace Exercício6_11M
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 1 - Novo
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        // 2 - Abrir
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.Text = File.ReadAllText(openFileDialog1.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir: " + ex.Message);
            }
        }

        // 3 - Guardar
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog1.FileName, richTextBox1.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao guardar: " + ex.Message);
            }
        }

        // 4 - Cortar
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        // 5 - Copiar
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        // 6 - Colar
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        // 7 - Desfazer
        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            if (richTextBox1.CanUndo)
                richTextBox1.Undo();
        }

        // 8 - Refazer
        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            if (richTextBox1.CanRedo)
                richTextBox1.Redo();
        }

        // 9 - Procurar (lupa)
        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            string palavra = Microsoft.VisualBasic.Interaction.InputBox("Procurar:", "Pesquisar");

            int pos = richTextBox1.Text.IndexOf(palavra);

            if (pos >= 0)
            {
                richTextBox1.Select(pos, palavra.Length);
                richTextBox1.Focus();
            }
            else
            {
                MessageBox.Show("Texto não encontrado.");
            }
        }

        // 10 - Inserir imagem
        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog img = new OpenFileDialog();
                img.Filter = "Imagens|*.jpg;*.png;*.bmp";

                if (img.ShowDialog() == DialogResult.OK)
                {
                    Clipboard.SetImage(System.Drawing.Image.FromFile(img.FileName));
                    richTextBox1.Paste();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir imagem: " + ex.Message);
            }
        }

        private void toolStripButton11_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle style = richTextBox1.SelectionFont.Style;
                if (richTextBox1.SelectionFont.Bold)
                    style &= ~FontStyle.Bold;
                else
                    style |= FontStyle.Bold;

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            }
        }

        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle style = richTextBox1.SelectionFont.Style;
                if (richTextBox1.SelectionFont.Italic)
                    style &= ~FontStyle.Italic;
                else
                    style |= FontStyle.Italic;

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            }
        }

        private void toolStripButton13_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle style = richTextBox1.SelectionFont.Style;
                if (richTextBox1.SelectionFont.Underline)
                    style &= ~FontStyle.Underline;
                else
                    style |= FontStyle.Underline;

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            }
        }

        private void toolStripButton14_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle style = richTextBox1.SelectionFont.Style;
                if (richTextBox1.SelectionFont.Strikeout)
                    style &= ~FontStyle.Strikeout;
                else
                    style |= FontStyle.Strikeout;

                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, style);
            }
        }

        private void toolStripButton15_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null)
            {
                float newSize = richTextBox1.SelectionFont.Size + 2;
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.FontFamily, newSize, richTextBox1.SelectionFont.Style);
            }
        }

        private void toolStripButton16_Click(object sender, EventArgs e)
        {
            if (richTextBox1.SelectionFont != null && richTextBox1.SelectionFont.Size > 2)
            {
                float newSize = richTextBox1.SelectionFont.Size - 2;
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont.FontFamily, newSize, richTextBox1.SelectionFont.Style);
            }
        }

        private void toolStripButton17_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionColor = cd.Color;
            }
        }

        // 18 - Cor de Fundo / Realce (Balde)
        private void toolStripButton18_Click(object sender, EventArgs e)
        {
            // Criamos uma nova instância do ColorDialog aqui dentro
            using (ColorDialog cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    richTextBox1.SelectionBackColor = cd.Color;
                }
            }
        }

        private void toolStripButton19_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont = fd.Font;
            }
        }
    }
}