<?php
    include("header.php");
?>

<p>As cores verde e amarela representam a esperança, a energia e o orgulho da cidade. O apelido “Leão da Alta Araraquarense” simboliza a coragem, a força e a garra que o Mirassol leva a cada partida, tornando-se um dos símbolos mais respeitados do futebol interiorano paulista.</p>

 <?php
    include("footer.php");
?>