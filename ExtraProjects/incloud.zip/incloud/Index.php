<?php
    include("header.php");
?>

<p>O Leão da Alta Araraquarense te dá as boas-vindas ao site oficial do clube. <br>
<strong>Fique por dentro da história, do elenco e torne-se um sócio-torcedor!</strong>
<br>

<?php
    include("footer.php");
?>