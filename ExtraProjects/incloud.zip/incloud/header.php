<html>
    <head>
        <title> Titulo </title>
        <link rel="stylesheet" href="seila.css">
    </head>
    <body>
        <a href = "Index.php">Inicio/</a>
        <a href = "pag1.php">Pagina 1 - História/</a>
        <a href = "pag2.php">Página 2 - História</a>

<?php
    echo "<br>Aqui ficará a parte de navegação <br>";
    echo "<br>";
?>