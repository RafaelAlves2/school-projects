<?php
    include("header.php");
?>

<p>O Mirassol Futebol Clube foi fundado em 9 de novembro de 1925,na cidade de Mirassol, interior de São Paulo. Nasceu do sonho de um grupo de moradores apaixonados por futebol, que desejavam representar a cidade em competições regionais. Desde os primeiros jogos, o clube mostrou a força e o orgulho do povo mirassolense.</p>

 <?php
    include("footer.php");
?>