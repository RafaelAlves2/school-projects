<?php
$servidor = "localhost";
$utilizador = "root";   
$senha_db = "";         
$base_dados = "jornal_futebol";

$conexao = new mysqli($servidor, $utilizador, $senha_db, $base_dados);

if ($conexao->connect_error) {
    die("Falha na ligação: " . $conexao->connect_error);
}
?>