<?php
include_once 'includes/header.php';
include_once 'basedados/bsdados.php';

$termo = isset($_GET['q']) ? trim($_GET['q']) : '';
$tipo = isset($_GET['tipo']) ? $_GET['tipo'] : 'noticias'; 
?>

<div class="busca-container">
    <h2>Pesquisar no Jornal</h2>
    <form action="buscar.php" method="GET" class="form-busca">
        <div class="form-group">
            <input type="text" name="q" id="q" placeholder="Digite o termo desejado..." value="<?php echo htmlspecialchars($termo); ?>" required>
        </div>
        <div class="form-group radio-group">
            <label><input type="radio" name="tipo" value="noticias" <?php echo $tipo == 'noticias' ? 'checked' : ''; ?>> Notícias</label>
            <label><input type="radio" name="tipo" value="comentarios" <?php echo $tipo == 'comentarios' ? 'checked' : ''; ?>> Comentários</label>
        </div>
        <button type="submit" class="btn blue">Pesquisar</button>
    </form>

    <?php if ($termo != ''): ?>
        <hr>
        <h3>Resultados para: "<?php echo htmlspecialchars($termo); ?>" (<?php echo $tipo == 'noticias' ? 'Notícias' : 'Comentários'; ?>)</h3>

        <?php if ($tipo == 'noticias'): ?>
            <?php
            $termo_like = "%$termo%";
            $stmt = $conexao->prepare("SELECT id, titulo, conteudo, imagem, data_publicacao, autor FROM noticias 
                                        WHERE titulo LIKE ? OR conteudo LIKE ? OR autor LIKE ? 
                                        ORDER BY data_publicacao DESC");
            $stmt->bind_param("sss", $termo_like, $termo_like, $termo_like);
            $stmt->execute();
            $resultado = $stmt->get_result();
            ?>
            <?php if ($resultado->num_rows > 0): ?>
                <div class="card-grid">
                    <?php while ($noticia = $resultado->fetch_assoc()): ?>
                        <div class="card">
                            <?php if (!empty($noticia['imagem'])): ?>
                                <img src="uploads/<?php echo $noticia['imagem']; ?>" alt="<?php echo htmlspecialchars($noticia['titulo']); ?>">
                            <?php endif; ?>
                            <div class="card-content">
                                <div class="card-title"><?php echo htmlspecialchars($noticia['titulo']); ?></div>
                                <p><?php echo substr(htmlspecialchars($noticia['conteudo']), 0, 150) . '...'; ?></p>
                                <p><small>📅 <?php echo date('d/m/Y', strtotime($noticia['data_publicacao'])); ?> | ✍️ <?php echo htmlspecialchars($noticia['autor']); ?></small></p>
                                <a href="noticia.php?id=<?php echo $noticia['id']; ?>" class="btn">Ler mais</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="sem-resultados">Nenhuma notícia encontrada com o termo "<?php echo htmlspecialchars($termo); ?>".</p>
            <?php endif; ?>
            <?php $stmt->close(); ?>

        <?php else: // pesquisa de comentários ?>
            <?php
            $termo_like = "%$termo%";
            $stmt = $conexao->prepare("SELECT c.*, n.titulo as noticia_titulo, n.id as noticia_id 
                                        FROM comentarios c 
                                        JOIN noticias n ON c.noticia_id = n.id 
                                        WHERE c.nome LIKE ? OR c.comentario LIKE ? 
                                        ORDER BY c.data_comentario DESC");
            $stmt->bind_param("ss", $termo_like, $termo_like);
            $stmt->execute();
            $resultado = $stmt->get_result();
            ?>
            <?php if ($resultado->num_rows > 0): ?>
                <div class="comentarios-resultados">
                    <?php while ($com = $resultado->fetch_assoc()): ?>
                        <div class="comentario-resultado">
                            <div class="comentario-cabecalho">
                                <span class="comentario-nome"><?php echo htmlspecialchars($com['nome']); ?></span>
                                <span class="comentario-data"><?php echo date('d/m/Y H:i', strtotime($com['data_comentario'])); ?></span>
                            </div>
                            <div class="comentario-texto">
                                <?php echo nl2br(htmlspecialchars($com['comentario'])); ?>
                            </div>
                            <div class="comentario-noticia">
                                <small>📰 Notícia: <a href="noticia.php?id=<?php echo $com['noticia_id']; ?>"><?php echo htmlspecialchars($com['noticia_titulo']); ?></a></small>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="sem-resultados">Nenhum comentário encontrado com o termo "<?php echo htmlspecialchars($termo); ?>".</p>
            <?php endif; ?>
            <?php $stmt->close(); ?>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include_once 'includes/footer.php'; ?>