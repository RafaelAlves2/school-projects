<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: utilizadores.php');
    exit;
}

$resultado = $conexao->query("SELECT * FROM utilizadores WHERE id = $id");
if ($resultado->num_rows == 0) {
    header('Location: utilizadores.php');
    exit;
}
$user = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = $_POST['senha'];

    // Verificar se o email já existe para outro utilizador
    $check = $conexao->query("SELECT id FROM utilizadores WHERE email = '$email' AND id != $id");
    if ($check->num_rows > 0) {
        $erro = "Este email já está a ser usado por outro utilizador.";
    } else {
        if (!empty($senha)) {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "UPDATE utilizadores SET nome='$nome', email='$email', senha='$senha_hash' WHERE id=$id";
        } else {
            $sql = "UPDATE utilizadores SET nome='$nome', email='$email' WHERE id=$id";
        }

        if ($conexao->query($sql)) {
            header('Location: utilizadores.php?msg=Utilizador atualizado com sucesso!');
            exit;
        } else {
            $erro = "Erro ao atualizar: " . $conexao->error;
        }
    }
}
?>

<h2>Editar Utilizador</h2>
<hr>

<?php if (isset($erro)): ?>
    <div class="msg-error"><?php echo $erro; ?></div>
<?php endif; ?>

<form action="" method="POST">
    <div class="form-group">
        <label for="nome">Nome completo *</label>
        <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($user['nome']); ?>" required>
    </div>

    <div class="form-group">
        <label for="email">Email *</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
    </div>

    <div class="form-group">
        <label for="senha">Nova senha</label>
        <input type="password" name="senha" id="senha">
        <small>Deixe em branco para manter a senha atual.</small>
    </div>

    <div class="form-group">
        <button type="submit" class="btn blue">Atualizar Utilizador</button>
        <a href="utilizadores.php" class="btn red">Cancelar</a>
    </div>
</form>

<?php include_once 'includes/admin_footer.php'; ?>