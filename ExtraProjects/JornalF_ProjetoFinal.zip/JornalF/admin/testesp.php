<?php
echo "Admin acessível!";
?>