<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';
include_once '../basedados/funcoes.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: noticias.php');
    exit;
}

$resultado = $conexao->query("SELECT * FROM noticias WHERE id = $id");
if ($resultado->num_rows == 0) {
    header('Location: noticias.php');
    exit;
}
$noticia = $resultado->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $conexao->real_escape_string($_POST['titulo']);
    $conteudo = $conexao->real_escape_string($_POST['conteudo']);
    $autor = $conexao->real_escape_string($_POST['autor']);
    $imagem_nome = $noticia['imagem']; // manter antiga se não enviar nova

    if (isset($_FILES['nova_imagem']) && $_FILES['nova_imagem']['error'] == 0) {
        $novo_nome = uploadImagem($_FILES['nova_imagem'], '../uploads/');
        if ($novo_nome) {
            // Apagar imagem antiga se existir
            if (!empty($noticia['imagem']) && file_exists('../uploads/' . $noticia['imagem'])) {
                unlink('../uploads/' . $noticia['imagem']);
            }
            $imagem_nome = $novo_nome;
        } else {
            $erro = "Erro ao fazer upload da nova imagem.";
        }
    }

    if (!isset($erro)) {
        $sql = "UPDATE noticias SET titulo='$titulo', conteudo='$conteudo', autor='$autor', imagem='$imagem_nome' WHERE id=$id";
        if ($conexao->query($sql)) {
            header('Location: noticias.php?msg=Notícia atualizada com sucesso!');
            exit;
        } else {
            $erro = "Erro ao atualizar: " . $conexao->error;
        }
    }
}
?>

<h2>Editar Notícia</h2>
<hr>

<?php if (isset($erro)): ?>
    <div class="msg-error"><?php echo $erro; ?></div>
<?php endif; ?>

<form action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label for="titulo">Título da Notícia *</label>
        <input type="text" name="titulo" id="titulo" value="<?php echo htmlspecialchars($noticia['titulo']); ?>" required>
    </div>

    <div class="form-group">
        <label for="conteudo">Conteúdo *</label>
        <textarea name="conteudo" id="conteudo" rows="10" required><?php echo htmlspecialchars($noticia['conteudo']); ?></textarea>
    </div>

    <div class="form-group">
        <label for="autor">Autor *</label>
        <input type="text" name="autor" id="autor" value="<?php echo htmlspecialchars($noticia['autor']); ?>" required>
    </div>

    <?php if (!empty($noticia['imagem'])): ?>
        <div class="form-group">
            <label>Imagem atual:</label>
            <div>
                <img src="../uploads/<?php echo $noticia['imagem']; ?>" alt="Imagem atual" style="max-width: 200px; max-height: 150px; border: 1px solid #ccc; padding: 5px;">
            </div>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <label for="nova_imagem">Nova imagem (opcional, para substituir)</label>
        <input type="file" name="nova_imagem" id="nova_imagem" accept="image/*">
        <small>Deixe em branco para manter a imagem atual.</small>
    </div>

    <div class="form-group">
        <button type="submit" class="btn blue">Atualizar Notícia</button>
        <a href="noticias.php" class="btn red">Cancelar</a>
    </div>
</form>

<?php include_once 'includes/admin_footer.php'; ?>