<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';
include_once '../basedados/funcoes.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $conexao->real_escape_string($_POST['titulo']);
    $conteudo = $conexao->real_escape_string($_POST['conteudo']);
    $autor = $conexao->real_escape_string($_POST['autor']);
    $imagem_nome = null;

    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $imagem_nome = uploadImagem($_FILES['imagem'], '../uploads/');
        if (!$imagem_nome) {
            $erro = "Erro ao fazer upload da imagem. Extensões permitidas: jpg, jpeg, png, gif.";
        }
    }

    if (!isset($erro)) {
        $sql = "INSERT INTO noticias (titulo, conteudo, imagem, autor) VALUES ('$titulo', '$conteudo', '$imagem_nome', '$autor')";
        if ($conexao->query($sql)) {
            header('Location: noticias.php?msg=Notícia inserida com sucesso!');
            exit;
        } else {
            $erro = "Erro ao inserir: " . $conexao->error;
        }
    }
}
?>

<h2>Inserir Notícia</h2>
<hr>

<?php if (isset($erro)): ?>
    <div class="msg-error"><?php echo $erro; ?></div>
<?php endif; ?>

<form action="" method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label for="titulo">Título da Notícia *</label>
        <input type="text" name="titulo" id="titulo" required>
    </div>

    <div class="form-group">
        <label for="conteudo">Conteúdo (texto completo) *</label>
        <textarea name="conteudo" id="conteudo" rows="10" required></textarea>
    </div>

    <div class="form-group">
        <label for="autor">Nome do Autor *</label>
        <input type="text" name="autor" id="autor" required>
    </div>

    <div class="form-group">
        <label for="imagem">Imagem de destaque (opcional)</label>
        <input type="file" name="imagem" id="imagem" accept="image/*">
        <small>Formatos permitidos: JPG, JPEG, PNG, GIF. Tamanho máximo: 2MB (recomendado).</small>
    </div>

    <div class="form-group">
        <button type="submit" class="btn green">Inserir Notícia</button>
        <a href="noticias.php" class="btn red">Cancelar</a>
    </div>
</form>

<?php include_once 'includes/admin_footer.php'; ?>