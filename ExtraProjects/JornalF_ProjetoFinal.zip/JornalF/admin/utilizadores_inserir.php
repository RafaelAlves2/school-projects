<?php
include_once 'includes/admin_header.php';
include_once '../basedados/bsdados.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $conexao->real_escape_string($_POST['nome']);
    $email = $conexao->real_escape_string($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    // Verificar se o email já existe
    $check = $conexao->query("SELECT id FROM utilizadores WHERE email = '$email'");
    if ($check->num_rows > 0) {
        $erro = "Este email já está registado. Escolha outro.";
    } else {
        $sql = "INSERT INTO utilizadores (nome, email, senha) VALUES ('$nome', '$email', '$senha')";
        if ($conexao->query($sql)) {
            header('Location: utilizadores.php?msg=Utilizador inserido com sucesso!');
            exit;
        } else {
            $erro = "Erro ao inserir: " . $conexao->error;
        }
    }
}
?>

<h2>Inserir Novo Utilizador</h2>
<hr>

<?php if (isset($erro)): ?>
    <div class="msg-error"><?php echo $erro; ?></div>
<?php endif; ?>

<form action="" method="POST">
    <div class="form-group">
        <label for="nome">Nome completo *</label>
        <input type="text" name="nome" id="nome" required placeholder="Ex: João Silva">
    </div>

    <div class="form-group">
        <label for="email">Email *</label>
        <input type="email" name="email" id="email" required placeholder="exemplo@dominio.com">
        <small>O email será usado para login na área administrativa.</small>
    </div>

    <div class="form-group">
        <label for="senha">Senha *</label>
        <input type="password" name="senha" id="senha" required>
        <small>Mínimo de 6 caracteres (recomendado).</small>
    </div>

    <div class="form-group">
        <button type="submit" class="btn green">Inserir Utilizador</button>
        <a href="utilizadores.php" class="btn red">Cancelar</a>
    </div>
</form>

<?php include_once 'includes/admin_footer.php'; ?>