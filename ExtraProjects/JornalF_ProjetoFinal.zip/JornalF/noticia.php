<?php
include_once 'includes/header.php';
include_once 'basedados/bsdados.php';

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$id) {
    header('Location: index.php');
    exit;
}

$query = "SELECT * FROM noticias WHERE id = $id";
$resultado = $conexao->query($query);
if ($resultado->num_rows == 0) {
    header('Location: index.php');
    exit;
}
$noticia = $resultado->fetch_assoc();

// Processar comentário
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comentario'])) {
    $nome = $conexao->real_escape_string(trim($_POST['nome']));
    $comentario = $conexao->real_escape_string(trim($_POST['comentario']));
    if (!empty($nome) && !empty($comentario)) {
        $sql = "INSERT INTO comentarios (noticia_id, nome, comentario) VALUES ($id, '$nome', '$comentario')";
        $conexao->query($sql);
        header("Location: noticia.php?id=$id");
        exit;
    } else {
        $erro = "Por favor, preencha o nome e o comentário.";
    }
}

$comentarios = $conexao->query("SELECT * FROM comentarios WHERE noticia_id = $id ORDER BY data_comentario DESC");
?>

<div class="noticia-container">
    <h1 class="noticia-titulo"><?php echo htmlspecialchars($noticia['titulo']); ?></h1>
    <div class="noticia-meta">
        <span class="data">📅 <?php echo date('d/m/Y H:i', strtotime($noticia['data_publicacao'])); ?></span>
        <span class="autor">✍️ <?php echo htmlspecialchars($noticia['autor']); ?></span>
    </div>

    <?php if (!empty($noticia['imagem'])): ?>
        <div class="noticia-imagem">
            <img src="uploads/<?php echo $noticia['imagem']; ?>" alt="<?php echo htmlspecialchars($noticia['titulo']); ?>">
        </div>
    <?php endif; ?>

    <div class="noticia-conteudo">
        <?php echo nl2br(htmlspecialchars($noticia['conteudo'])); ?>
    </div>

    <hr class="separador">

    <div class="comentarios-section">
        <h3>💬 Comentários (<?php echo $comentarios->num_rows; ?>)</h3>

        <?php if ($comentarios->num_rows > 0): ?>
            <?php while ($com = $comentarios->fetch_assoc()): ?>
                <div class="comentario">
                    <div class="comentario-cabecalho">
                        <span class="comentario-nome"><?php echo htmlspecialchars($com['nome']); ?></span>
                        <span class="comentario-data"><?php echo date('d/m/Y H:i', strtotime($com['data_comentario'])); ?></span>
                    </div>
                    <div class="comentario-texto">
                        <?php echo nl2br(htmlspecialchars($com['comentario'])); ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="sem-comentarios">Seja o primeiro a comentar!</p>
        <?php endif; ?>
    </div>

    <div class="form-comentario">
        <h3>✍️ Deixe o seu comentário</h3>
        <?php if (isset($erro)): ?>
            <div class="msg-error"><?php echo $erro; ?></div>
        <?php endif; ?>
        <form action="noticia.php?id=<?php echo $id; ?>" method="POST">
            <div class="form-group">
                <label for="nome">Seu nome</label>
                <input type="text" name="nome" id="nome" required placeholder="Ex: João Silva">
            </div>
            <div class="form-group">
                <label for="comentario">Comentário</label>
                <textarea name="comentario" id="comentario" rows="4" required placeholder="Escreva aqui o seu comentário..."></textarea>
            </div>
            <button type="submit" class="btn blue">Enviar Comentário</button>
        </form>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>